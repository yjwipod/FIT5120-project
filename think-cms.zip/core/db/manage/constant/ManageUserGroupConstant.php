<?php

namespace core\db\manage\constant;

class ManageUserGroupConstant
{
    /**
     * 根菜单的上级群组编号值
     */
    const ROOT_PNO_VALUE = '';
}