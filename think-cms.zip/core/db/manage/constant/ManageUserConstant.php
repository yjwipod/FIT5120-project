<?php

namespace core\db\manage\constant;

class ManageUserConstant
{

    /**
     * 启用
     */
    const STATUS_ENABLE = 1;

    /**
     * 禁用
     */
    const STATUS_DISABLE = 0;

}