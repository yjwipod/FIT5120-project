<?php

namespace core\db\manage\model;

use core\base\Model;

class ManageUserGroupLinkModel extends Model
{
    protected $name = 'manage_user_group_link';

    protected $autoWriteTimestamp = false;
}