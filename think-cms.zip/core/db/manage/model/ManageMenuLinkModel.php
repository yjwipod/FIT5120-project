<?php

namespace core\db\manage\model;


use core\base\Model;

class ManageMenuLinkModel extends Model
{
    protected $name = 'manage_menu_link';

    protected $autoWriteTimestamp = false;
}