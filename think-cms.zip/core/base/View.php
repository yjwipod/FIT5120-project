<?php

namespace core\base;

use cms\core\traits\InstanceTrait;

class View
{
    /**
     * 实例trait
     */
    use InstanceTrait;
}