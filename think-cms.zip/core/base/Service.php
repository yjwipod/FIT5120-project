<?php

namespace core\base;

use cms\core\traits\InstanceTrait;
use cms\core\traits\ReturnTrait;

class Service
{
    // 实例trait
    use InstanceTrait;

    // 返回trait
    use ReturnTrait;
}