<?php

namespace core\base;

use cms\core\traits\InstanceTrait;

class Validate extends \think\Validate
{
    /**
     * 实例trait
     */
    use InstanceTrait;
}